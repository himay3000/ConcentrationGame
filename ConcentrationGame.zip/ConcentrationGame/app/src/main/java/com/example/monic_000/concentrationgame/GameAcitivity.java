package com.example.monic_000.concentrationgame;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by monic_000 on 11/26/2017.
 */

public class GameAcitivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_activity);
    }
}
